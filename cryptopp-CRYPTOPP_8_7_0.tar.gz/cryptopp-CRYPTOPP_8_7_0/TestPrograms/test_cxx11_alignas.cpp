int main(int argc, char* argv[])
{
    alignas(8) unsigned char x[16];
    return 0;
}
